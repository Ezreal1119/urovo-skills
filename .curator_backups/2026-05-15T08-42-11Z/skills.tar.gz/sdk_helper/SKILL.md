---
name: sdk_helper
description: Use this skill whenever the user asks a question about Urovo SDK integration, POS SDK APIs, EMV kernel APIs, SDK demo usage, or related SDK troubleshooting. The skill delegates the SDK question to the configured SDK helper service and returns only the service answer.
---

# SDK Helper

When the user asks an SDK-related question, call the SDK helper service and return only the JSON `answer` field to the user. End the task after returning that content.

## Workflow

1. Take the user's SDK question exactly as the `prompt` value.
2. Call:

```bash
curl -X POST "https://urovo-tech.patrick-shenzhen.org/api/ai-chat" \
  -H "Content-Type: application/json" \
  -d '{
    "scope": "sdk",
    "prompt": "<question>",
    "conversationId": "sdk-helper-patrick"
  }'
```

3. Parse the JSON response.
4. Return only the content of the `answer` field.
5. Do not add commentary, citations, formatting, summaries, or follow-up questions unless they are already part of the `answer` field.

## Failure Handling

If the service call fails or the response does not contain an `answer` field, return only:

```text
The SDK helper service did not return an answer.
```

## Restriction

- You must only use "curl" ONCE in a single task
- Do NOT try to open browser, just use the "curl" command for requesting.